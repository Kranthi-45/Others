import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
@Injectable({
  providedIn: 'root'
})
export class MovieService {

  url:string='http://localhost:8081/movie';
  
  constructor(private http:HttpClient) { }


  addMovie(movie:any)
  {
    alert("movie service "+JSON.stringify(movie));
    
    return this.http.post(this.url,movie);
  }

  getAllMovie(){
    return this.http.get(this.url);
  }

  modifyMovie(movie:any)
  {
    return this.http.put(this.url,movie);
  }
  removeMovie(id:any)
  {
    alert("theatre service  remove theatre "+JSON.stringify(id));
    return this.http.delete(this.url+"/"+id);
  }

}
