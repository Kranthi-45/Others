export class Theatre {
    id:number | undefined;
    name:string | undefined;
    movieList: any[] | undefined;
}
