import { Theatre } from "./theatre";

export class Movie {
    id:number | undefined;
    movieName:string | undefined;
    theatre: Theatre | undefined;
}
