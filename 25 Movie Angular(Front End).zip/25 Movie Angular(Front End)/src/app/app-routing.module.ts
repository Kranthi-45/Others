import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { BookDetailsComponent } from './book-details/book-details.component';
import { BookComponent } from './book/book.component';
import { HomeUserComponent } from './home-user/home-user.component';
import { HomeComponent } from './home/home.component';
import { LoginComponent } from './login/login.component';
import { LogoutComponent } from './logout/logout.component';
import { MovieComponent } from './movie/movie.component';
import { PaymentBookComponent } from './payment-book/payment-book.component';
import { SignupComponent } from './signup/signup.component';
import { TheatreComponent } from './theatre/theatre.component';

const routes: Routes = [
  {path:"login",component:LoginComponent},
  {path:"signup",component:SignupComponent},
  {path:"home",component:HomeComponent},
  {path:"logout",component:LogoutComponent},
  {path:"homeUser",component:HomeUserComponent},
  {path:"movie",component:MovieComponent},
  {path:"theatre",component:TheatreComponent},
  {path:"booking",component:BookComponent},
  {path:"myBookings",component:BookDetailsComponent},
  {path:"payBook",component:PaymentBookComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
