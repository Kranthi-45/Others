import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';
import { Book } from '../book';
import { BookService } from '../book.service';
import { MovieService } from '../movie.service';
import { PayBookService } from '../pay-book.service';
import { PaymentBookComponent } from '../payment-book/payment-book.component';

@Component({
  selector: 'app-book',
  templateUrl: './book.component.html',
  styleUrls: ['./book.component.css']
})
export class BookComponent implements OnInit {

  movies:any;
  movieForm:any;
  constructor(private fb:FormBuilder, private ms: MovieService, private bs:BookService, private router:Router, private ps: PayBookService) {
    this.movieForm=this.fb.group({
      movieId:[],
      movieName:[],
      theatreId:[]
    })
   }

  ngOnInit(): void {
    this.ms.getAllMovie().subscribe((data)=>{
      console.log(data);
      this.movies=data;                                  
     });
  }

  fnBook(mov:any){
    alert(JSON.stringify(mov));
    if(localStorage.getItem('user')==null)
    {
      console.log("NOt logged in.")
      return;
    }
    var str=localStorage.getItem('user');
    if(str!=null){
      var user=JSON.parse(str);
      alert(JSON.stringify(str));
      var customer_id=user.userId;
      var book = new Book(); 
         book.bookDate=new Date();
         book.theatreId=mov.theatreId;
         book.movieId=mov.movieId;
         book.customerId=customer_id;
         book.tickets=1;
         alert(JSON.stringify(book))
         console.log("Going to place an order as below");
         console.log(book);
                                                                          //   this.ps.payBook(book);
      // this.bs.bookTicket(book).subscribe(data=>console.log(data));
      this.bs.bookTicket(book).subscribe(data=>console.log(data));

      
      this.ms.getMovieById(book.movieId).subscribe((data)=>{
        this.movieForm.patchValue(data);                       
      });
      this.ps.bookTicket(book);
      //this.router.navigate(['/payBook']);

   }
    alert(str);
    //
    // var customer_id=customer.id;
  }
  fnAdd(){
    this.router.navigate(['/payBook']);
  }
  fnDelete(){}


//   fnBuy(id)
//   {
//     alert(id);
//     if(localStorage.getItem('customer')==null)
//     {
//       console.log("NOt logged in.")
//       return;
//     }
//     var str=localStorage.getItem('customer');
//     var customer=JSON.parse(str);
//     var customer_id=customer.id;
//     var order=new Order();
//     order.orderDate=new Date();
//     order.productId=id;
//     order.customerId=customer_id;
//     order.quantity=1;
//     console.log("Going to place an order as below");
//     console.log(order);
//     this.os.placeOrder(order).subscribe(data=>console.log(data));
//  }
}
