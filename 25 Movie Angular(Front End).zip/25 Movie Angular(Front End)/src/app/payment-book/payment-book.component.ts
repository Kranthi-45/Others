import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { Book } from '../book';
import { BookService } from '../book.service';
import { MovieService } from '../movie.service';
import { PayBookService } from '../pay-book.service';

@Component({
  selector: 'app-payment-book',
  templateUrl: './payment-book.component.html',
  styleUrls: ['./payment-book.component.css']
})
export class PaymentBookComponent implements OnInit {

  movies:any;
  book:any;
  constructor(private fb:FormBuilder,private bs:BookService,private ms: MovieService, private ps: PayBookService ) { 
    // this.ms.getAllMovie().subscribe((data)=>{
    //   console.log(data);
    //   this.movies=data;                                  
    //  });
  }
  
  ngOnInit(): void {
    this.book = this.ps.fnBook();
    alert("payment init component "+ JSON.stringify(this.book))
    alert( JSON.stringify(this.book.theatreId))
  }
  
  //  book:any;

  // payBook(book:any)

  //   this.bs.bookTicket(book).subscribe(data=>console.log(data));
  // }


}