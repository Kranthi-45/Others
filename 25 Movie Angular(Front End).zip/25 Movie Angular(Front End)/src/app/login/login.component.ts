import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';
import { MyUser } from '../my-user';
import { UserService } from '../user.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  loginForm:any;
  users:any;
  admin:any;

  constructor(private fb:FormBuilder, private us:UserService, private router:Router) { 
    this.loginForm=this.fb.group({
      username:[],
      password:[],
      admin:[],
    });
  }
  signStatus:any;
  ngOnInit(): void {
    this.us.getAllUsers().subscribe((data)=>{
      console.log(data);
      this.users=data;                                  
     })
  }
 
  login()
  {
    var admin = this.loginForm.controls['admin'].value;
    alert(admin)

    var username=this.loginForm.controls['username'].value;
    var password=this.loginForm.controls['password'].value;
    this.signStatus = true;
    // alert('logging in '+username+" - "+password);
    this.us.login(username,password).subscribe((data)=>{
      console.log(data)
      //login failed/success what to do all  these logics to be written inside this lamdba 
      //i am going to notify menu component now
      this.us.loginStatus();
      if(data!=null)
      {
        var user:any;
        user=data;
        localStorage.setItem("user",JSON.stringify(user));
        this.us.loginStatus().subscribe();
        if(admin) {
        this.router.navigate(['/home']);
        }
        else{
          this.router.navigate(['/homeUser']);
        }
      }else{
        localStorage.setItem("user",JSON.stringify(null));
      }
    });
    //not here
  } 
}
