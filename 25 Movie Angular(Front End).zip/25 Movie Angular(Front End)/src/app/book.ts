export class Book {
    // private Long id;
	// private Date bookDate;
	// private Long theatreId;
	// private Long movieId;
	// private Long customerId;
	// private Long tickets;
	
    id:number=0;
    bookDate:Date=new Date();
    theatreId:number=0;
    movieId:number=0;
    customerId:number=0;
    tickets:number=0;
}
